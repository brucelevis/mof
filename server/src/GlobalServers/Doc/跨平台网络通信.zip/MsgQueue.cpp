/*-------------------------------------------------------------------------
	created:	2010/08/23  14:42
	filename: 	e:\Project_SVN\Server\Utils\MessageQueue\MsgQueue.cpp
	author:		Deeple

	purpose:
---------------------------------------------------------------------------*/


#include "MsgQueue.h"

//class CSafeQueue
//---------------------------------------------------------------------------
CSafeQueue::CSafeQueue()
{

}

CSafeQueue::~CSafeQueue()
{
	Clear();
}

void CSafeQueue::PushMessage(CMsgTyped* pmsg, bool bSetAsReadBuf)
{
	if (!pmsg)
	{
		return;
	}

	CMsgTyped* pInsert = new CMsgTyped(0);
	pInsert->Swap(*pmsg);

	if (bSetAsReadBuf)
	{
		pInsert->SetAsReadBuf(true);
		pInsert->SeekToBegin();
	}

	Lock();

	m_msgQueue.push(pInsert);

	Unlock();
}

void CSafeQueue::PushMessageNoWait(CMsgTyped* pmsg, bool bSetAsReadBuf)
{
	if (!pmsg)
	{
		return;
	}

	CMsgTyped* pInsert = new CMsgTyped(0);
	pInsert->Swap(*pmsg);

	if (bSetAsReadBuf)
	{
		pInsert->SetAsReadBuf(true);
		pInsert->SeekToBegin();
	}

	Lock();

	m_msgQueue.push(pInsert);

	Unlock();
}

void CSafeQueue::MsgWait()
{

}

CMsgTyped* CSafeQueue::GetMessage()
{
	Lock();

	if (m_msgQueue.size() == 0)
	{
		Unlock();
		return NULL;
	}

	CMsgTyped* pMsg = m_msgQueue.front();
	m_msgQueue.pop();

	Unlock();

	return pMsg;
}

void CSafeQueue::Clear()
{
	Lock();

	while (m_msgQueue.size() > 0)
	{
		CMsgTyped* p = m_msgQueue.front();
		delete p;
		m_msgQueue.pop();
	}

	Unlock();
}

size_t CSafeQueue::MsgCount()
{
	size_t ret = 0;

	Lock();

	ret = m_msgQueue.size();

	Unlock();

	return ret;
}
