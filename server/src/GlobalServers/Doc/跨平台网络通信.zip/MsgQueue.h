/*-------------------------------------------------------------------------
	created:	2010/08/23  14:42
	filename: 	e:\Project_SVN\Server\Utils\MessageQueue\MsgQueue.h
	author:		Deeple

	purpose:
---------------------------------------------------------------------------*/

#pragma once
#include "MsgBuf.h"

#ifndef WIN32
	#include <pthread.h>
	#include <semaphore.h>
	#include <unistd.h>
#else
	#include <windows.h>
#endif

#include <queue>
#include <string>

// 自动�?// 线程安全对象
class CriticalObject
{
public:
	CriticalObject(void)
	{
#ifndef WIN32
	    pthread_mutexattr_t attr;
	    pthread_mutexattr_init(&attr);
	    pthread_mutexattr_settype(&attr,PTHREAD_MUTEX_RECURSIVE_NP);

        pthread_mutex_init(&mtx, &attr);
#else
		InitializeCriticalSection(&cs);
#endif
	}
	virtual ~CriticalObject(void)
	{
#ifndef WIN32
        pthread_mutex_destroy( &mtx );
#else
		DeleteCriticalSection(&cs);
#endif
	}
	void Lock()
	{
#ifndef WIN32
        pthread_mutex_lock( &mtx );
#else
		EnterCriticalSection(&cs);
#endif
	}
	bool TryLock()
	{
#ifndef WIN32
         return ( pthread_mutex_trylock( &mtx ) == 0 );
#endif
	}
	void Unlock()
	{
#ifndef WIN32
        pthread_mutex_unlock( &mtx );
#else
		LeaveCriticalSection(&cs);
#endif
	}
private:
#ifndef WIN32
    pthread_mutex_t mtx;
#else
	CRITICAL_SECTION cs;
#endif
};

class WEvent : public CriticalObject
{
public:
    WEvent(){ m_nRef = 1; }
    ~WEvent(){}

    bool WaitEvent(size_t msecs = -1)
    {
        while (msecs --)
        {
            Lock();

            if (m_nRef == 0)
            {
                Unlock();
                return true;
            }

            Unlock();
#ifdef WIN32
			Sleep(1);
#else
            usleep(1000);
#endif
        }

        return false;
    }

    void SetEvent()
    {
        Lock();

        if (m_nRef > 0)
        {
            m_nRef -- ;
        }

        Unlock();
    }

    void ResetEvent()
    {
        Lock();

        m_nRef = 1;

        Unlock();
    }

private:
    int m_nRef;
};

// ������
class SmartLock
{
public:
	SmartLock(CriticalObject* pObj)
	{
		m_pObject = pObj;
		if (m_pObject)
		{
			m_pObject->Lock();
		}
	}
	~SmartLock()
	{
		if (m_pObject)
		{
			m_pObject->Unlock();
		}
	}
	CriticalObject* m_pObject;
};

#define SMART_LOCK(obj) SmartLock lock(obj)
#define SMART_LOCK_THIS() SmartLock lock_this(this)

class CSafeQueue : public CriticalObject
{
public:
	CSafeQueue();
	~CSafeQueue();

	void PushMessage(CMsgTyped* pmsg, bool bSetAsReadBuf = true);
	void PushMessageNoWait(CMsgTyped* pmsg, bool bSetAsReadBuf = true);
	void MsgWait();
	CMsgTyped* GetMessage();
	void Clear();
	size_t MsgCount();

private:
	std::queue<CMsgTyped*> m_msgQueue;
};

