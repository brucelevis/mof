/*-------------------------------------------------------------------------
	created:	2010/08/16  16:10
	filename: 	SyncSock.cpp
	author:		Deeple

	purpose:
---------------------------------------------------------------------------*/

#include "SyncSock.h"

#ifndef WIN32
	#include <netinet/in.h>
	#include <arpa/inet.h>
#endif

bool InitSocket()
{
#ifdef WIN32
	WSADATA wsaData;
	WORD sockVersion = MAKEWORD(2, 2);
	if(::WSAStartup(sockVersion,&wsaData) != 0)
	{
	 return false;
	}
#endif

    return true;
}

SOCKET ConnectServer(const char* addr, u_short uPort)
{
	SOCKET ConnectSocket = socket(AF_INET, SOCK_STREAM, 0);
	if (ConnectSocket == INVALID_SOCKET)
	{
		return INVALID_SOCKET;
	}

	sockaddr_in clientService;
	clientService.sin_family = AF_INET;
	clientService.sin_addr.s_addr = addr ? inet_addr(addr) : 0;
	clientService.sin_port = htons(uPort);

	if (connect(ConnectSocket, (struct sockaddr *)&clientService, sizeof(clientService)) != 0)
	{
#ifndef WIN32
		close(ConnectSocket);
#else
		closesocket(ConnectSocket);
#endif
		return INVALID_SOCKET;
	}

	int nodelay = 1;
	setsockopt(ConnectSocket,IPPROTO_TCP, TCP_NODELAY,(char*)&nodelay, sizeof(int));

	return ConnectSocket;
}

void CloseConn(SOCKET& s)
{
#ifndef WIN32
		close(s);
#else
		closesocket(s);
#endif
	s = INVALID_SOCKET;
}

bool SendData(SOCKET& s, void* pData, int nLen)
{
	if (!pData)
		return false;

	char * chData = (char*) pData;

	int nSent = 0;

	while (nSent < nLen)
	{
		int n = ::send(s, chData + nSent, nLen - nSent, 0);
		if (n < 1)
		{
			CloseConn(s);
			return false;
		}
		nSent += n;
	}

	return true;
}

bool RecvData(SOCKET& s, void* pData, int nLen)
{
	if (!pData)
		return false;

	char * chData = (char*) pData;

	int nRecvd = 0;

	while (nRecvd < nLen)
	{
		int n = ::recv(s, chData + nRecvd, nLen - nRecvd, 0);
		if (n < 1)
		{
			CloseConn(s);
			return false;
		}
		nRecvd += n;
	}

	return true;
}

bool SendMsg(SOCKET& s, void* pData, int nLen)
{
	if (SendData(s, &nLen, sizeof(int))
		&& SendData(s, pData, nLen))
	{
		return true;
	}
	return false;
}

bool RecvMsg(SOCKET& s, char* pRecvBuf, size_t& nBufLen)
{
	size_t nMsgLen = 0;

	if (!RecvData(s, &nMsgLen, sizeof(int)))
	{
		return false;
	}

	if (nMsgLen > nBufLen)
	{
		CloseConn(s);
		return false;
	}

	if (!RecvData(s, pRecvBuf, (int)nMsgLen))
	{
		return false;
	}

	nBufLen = nMsgLen;

	return true;
}


// class SyncSock
//-------------------------------------------------------------
#define AUX_RECV_BUF_SIZE (1024 * 1024)

CAsyncSocket::CAsyncSocket()
{
	m_hConnSock = INVALID_SOCKET;

	m_SendThread.m_hWorkThread = NULL;
	m_RecvThread.m_hWorkThread = NULL;

	m_bRunning = false;

	m_pRecvBuf = NULL;
}

CAsyncSocket::~CAsyncSocket()
{
	ShutDown();

	if (m_pRecvBuf)
	{
	    delete [] m_pRecvBuf;
	}
}

bool CAsyncSocket::Open(const char* ServerIP, u_short uPort)
{
	if (m_bRunning)
	{
		ShutDown();
	}

	if (!ServerIP)
	{
		return false;
	}

	m_szIP = ServerIP;
	m_uPort = uPort;

	m_bRunning = true;

	if (!m_pRecvBuf)
	{
	    m_pRecvBuf = new char[ AUX_RECV_BUF_SIZE ];
	}

#ifndef WIN32
    pthread_create(&m_RecvThread.m_hWorkThread, NULL, RecvProc, (void*)this);
    pthread_create(&m_SendThread.m_hWorkThread, NULL, SendProc, (void*)this);
#else
	CreateThread(NULL, 0, RecvProc, (void*)this, 0, 0);
	CreateThread(NULL, 0, SendProc, (void*)this, 0, 0);
#endif

	return true;
}

void CAsyncSocket::ShutDown()
{
	if (!m_bRunning)
	{
		return;
	}

	m_bRunning = false;

	// �ر���������
	CloseConn(m_hConnSock);

	// �ȴ�50ms
	m_SendThread.m_exitEvent.WaitEvent(50);
	m_RecvThread.m_exitEvent.WaitEvent(50);

	// �رվ��
#ifndef WIN32
	pthread_cancel(m_SendThread.m_hWorkThread);
	pthread_cancel(m_RecvThread.m_hWorkThread);
#else
	TerminateThread(m_SendThread.m_hWorkThread, 0);
	TerminateThread(m_RecvThread.m_hWorkThread, 0);
#endif

    m_SendThread.m_hWorkThread = NULL;
	m_RecvThread.m_hWorkThread = NULL;

	// ������Ϣ����
	m_RecvThread.m_MessageQueue.Clear();
	m_SendThread.m_MessageQueue.Clear();
}

bool CAsyncSocket::SendMessage(CMsgTyped* pMsg, bool bFailIFBadSock)
{
	if (bFailIFBadSock)
	{
		if (m_hConnSock == INVALID_SOCKET)
		{
			return false;
		}
	}

	// �ѻ�����10������Ϣ��ʱ, ��ֹͣ
	if (m_SendThread.m_MessageQueue.MsgCount() > 204800)
	{
		m_SendThread.m_MessageQueue.Clear();
		return false;
	}

	m_SendThread.m_MessageQueue.PushMessageNoWait(pMsg, false);

	return true;
}

bool CAsyncSocket::ProcessMessages()
{
	bool bRet = false;
	CMsgTyped* pmsg = NULL;
	while ((pmsg = m_RecvThread.m_MessageQueue.GetMessage()) != NULL)
	{
		bRet = true;
		try
		{
			OnReceive(pmsg);
		}
		catch (...)
		{
		}
		delete pmsg;
	}

	return bRet;
}

void CAsyncSocket::OnReceive(CMsgTyped* pmsg)
{
	// �����ص�
}



#ifdef WIN32
DWORD WINAPI CAsyncSocket::SendProc(void* lpParam)
#else
void* CAsyncSocket::SendProc(void* lpParam)
#endif
{
	CAsyncSocket* pThis = (CAsyncSocket*)lpParam;

	if (!pThis)
	{
		return 0;
	}

	CMsgTyped* pSendMsg = NULL;

	SOCKET& s = pThis->m_hConnSock;

	while (pThis->m_bRunning)
	{
		// �������������Ч, �ȴ�
		if (s == INVALID_SOCKET)
		{
#ifndef WIN32
			usleep(1000000);
#else
			Sleep(1000);
#endif
			continue;
		}

		// ��ȡ��Ϣ
		pSendMsg = pThis->m_SendThread.m_MessageQueue.GetMessage();
		if (!pSendMsg)
		{
#ifndef WIN32
			usleep(10000);
#else
			Sleep( 10 );
#endif
			continue;
		}

		// ��������
		// ��������
		SendMsg(s, (void*)pSendMsg->GetData(), (int)pSendMsg->GetLength());

		delete pSendMsg;
	}

	pThis->m_SendThread.m_exitEvent.SetEvent();

	return 0;
}

#ifdef WIN32
DWORD WINAPI CAsyncSocket::RecvProc(void* lpParam)
#else
void* CAsyncSocket::RecvProc(void* lpParam)
#endif
{
	CAsyncSocket* pThis = (CAsyncSocket*)lpParam;

	if (!pThis)
	{
		return 0;
	}

	char* recv_data = pThis->m_pRecvBuf;
	size_t recv_buf_len;

	SOCKET& s = pThis->m_hConnSock;

	// ����ʧ�ܴ���
	int nRetryConnect = 1;

	while (pThis->m_bRunning)
	{
		// ά��socket����
		if (s == INVALID_SOCKET)
		{
			s = ConnectServer(pThis->m_szIP.c_str(), pThis->m_uPort);
			if (s == INVALID_SOCKET)
			{
				// ���ӶϿ�
				pThis->OnConnectFailed(nRetryConnect ++);
#ifndef WIN32
                usleep(1000000);
#else
				Sleep( 1000 );
#endif
				continue;
			}

			// ��������, ֪ͨ�߼�
			pThis->OnConnected();
		}

		if (!pThis->m_bRunning) break;

		// ��������
		recv_buf_len = AUX_RECV_BUF_SIZE;
		if (RecvMsg(s, recv_data, recv_buf_len))
		{
			CMsgTyped response(recv_buf_len, recv_data);
			pThis->m_RecvThread.m_MessageQueue.PushMessage(&response);
		}
		else
		{
			// ���ӶϿ�
			pThis->OnDisconnected();
		}
	}

	pThis->m_RecvThread.m_exitEvent.SetEvent();

	return 0;
}

