#include <iostream>
#include <stdio.h>

#include "SyncSock.h"

using namespace std;

class MySocketHandle : public CAsyncSocket
{
public:
    // 处理逻辑包接收
	virtual void OnReceive(CMsgTyped* pmsg)
	{
	    printf("recv message <- ");
	    pmsg->Dump();
	}

	// 连接建立和断开事件, 调用者为接收线程，故需要注意线程安全
	virtual void OnConnected(){ printf("connected.\n"); };
	virtual void OnDisconnected(){ printf("disconnected.\n"); };
};

MySocketHandle g_Socket;

int main()
{
	InitSocket();

    // 连接到服务器
    g_Socket.Open( "192.168.2.23", 8080 );

    // 发送登陆消息
	CMsgTyped login;
    login.SetInt( 0 );
    login.SetInt( 0 );
    login.SetString( "acct" );
    login.SetString( "pwd" );

    printf("send message -> ");
    login.Dump();

    g_Socket.SendMessage( &login );

    while (1)
    {
        if (!g_Socket.ProcessMessages())
        {
            // 没有网络消息， 等待一小段时间

#ifndef WIN32
			usleep( 10000 );
#else
			Sleep( 10 );
#endif

		}
    }

    return 0;
}

